INSERT INTO company (company_name, city) VALUES
('First Bank', 'New York'),
('Land Bank', 'Los Angeles'),
('Prime Technologies', 'San Diego'),
('Blue Sky Inc', 'New York'),
('GreenTech', 'New York'),
('Red Rock Solutions', 'Orlando'),
('Dynamic Innovations', 'Austin'),
('Tech Innovations', 'Los Angeles');


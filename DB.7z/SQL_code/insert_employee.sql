INSERT INTO employee (employee_name, street, city) VALUES
('John Doe', '123', 'Taiwan');


INSERT INTO employee (employee_name, street, city) VALUES
('John Doe', '123 Main St', 'New York'),
('Jane Smith', '456 Elm St', 'Los Angeles'),
('Michael Johnson', '789 Oak St', 'Chicago'),
('Emily Davis', '101 Pine St', 'Houston'),
('Christopher Wilson', '222 Maple St', 'San Francisco'),
('Jessica Taylor', '333 Cedar St', 'Boston'),
('Daniel Anderson', '444 Walnut St', 'Seattle'),
('Sarah Martinez', '555 Birch St', 'Miami'),
('David Thompson', '666 Ash St', 'Denver'),
('Jennifer Rodriguez', '777 Elm St', 'Atlanta'),
('James Garcia', '888 Pine St', 'Dallas'),
('Linda Hernandez', '999 Oak St', 'New York'),
('William Martinez', '111 Maple St', 'Philadelphia'),
('Patricia Gonzalez', '222 Cedar St', 'Detroit'),
('Richard Perez', '123 Main St', 'New York'),
('Susan Ramirez', '444 Birch St', 'Minneapolis'),
('Daniel Lewis', '555 Ash St', 'Tampa'),
('Maria Walker', '666 Elm St', 'Portland'),
('Charles King', '777 Pine St', 'Orlando'),
('Karen Wright', '888 Oak St', 'Austin');



/*('Mark Johnson', '555 Ash St', 'Boston'),
('Amy Lee', '999 Oak St', 'Phoenix'),
('Tom Brown', '333 Cedar St', 'Boston'),
('Emma White', '456 Elm St', 'Los Angeles'),
('Ryan Adams', '123 Main St', 'New York'),
('Olivia Clark', '222 Maple St', 'San Francisco'),
('Erica Hall', '666 Elm St', 'Portland'),
('Kevin Turner', '777 Pine St', 'Orlando'),
('Laura Baker', '888 Oak St', 'Dallas'),
('Chris Evans', '101 Pine St', 'Houston');*/



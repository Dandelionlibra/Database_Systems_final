-- 先刪view才可以刪除與view有關聯的表格
-- DROP VIEW employee_avg_salary;

DROP TABLE manages;
DROP TABLE works;
DROP TABLE company;
DROP TABLE employee;


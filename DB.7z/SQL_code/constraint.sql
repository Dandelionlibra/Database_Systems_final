-- INSERT INTO employee (employee_name, street, city) VALUES
-- ('Dandelion', '123', 'Chiayi'),
-- ('Fiona', '123', 'Hsinchu'),
-- ('Pearl', '123', 'Miaoli'),
-- ('Jenny', '123', 'Hsinchu');


-- INSERT INTO company (company_name, city) VALUES
-- ('Chung Yuan', 'Taoyuan');

-- SELECT *
-- FROM company

-- SELECT *
-- FROM employee



INSERT INTO manages (employee_name, manager_name) VALUES
('Haung Yijia', 'Jenny');


-- INSERT INTO works (employee_name, company_name, salary) VALUES
-- ('Dandelion', 'Chung Yuan', 70000),
-- ('Fiona', 'Chung Yuan', -100),
-- ('Pearl', 'Chung Yuan', 50000),
-- ('Jenny', 'Chung Yuan', 1000000);

-- SELECT *
-- FROM works